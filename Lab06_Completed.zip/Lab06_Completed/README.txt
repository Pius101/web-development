COS10005 WEB DEVELOPMENT - LAB EXERCISE 6
CSS Responsive Layout and Accessibility

COMPLETED FILES
    regform.html    Final registration form, linking to style.css
    desktop.css     Step 3: one desktop rule (red text)
    mobile.css      Step 4: mobile-specific rules
    style.css       Step 5: both styles merged with media queries

HOW TO USE
1. Keep regform.html and the three CSS files in the same folder.
2. Open regform.html in Chrome, Edge, or Firefox.
3. At browser widths of 768 pixels or more, the text becomes red.
4. At browser widths of 480 pixels or less, the text becomes blue,
   fonts enlarge, fields stack, and the submit button is centered.
5. Screen widths from 481-767 pixels retain default browser styles,
   because the lab specifically instructs 768px and 480px breakpoints.
6. To demonstrate Step 2 before merging the stylesheets, uncomment
   the desktop.css and mobile.css links in the HTML head and comment
   out the active style.css link. Restore style.css for final submission.

NOTES
- The original mailto:abc@gmail.com action has been preserved from the
  supplied exercise file. It is not a real registration backend. Never
  enter a real password into this demonstration form or deploy the form
  to collect credentials by email.
- Both the HTML and CSS use standard syntax; test the documents with
  https://validator.w3.org/ and https://jigsaw.w3.org/css-validator/.
